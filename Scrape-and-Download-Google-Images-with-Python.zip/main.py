import bs4_original_images, bs4_suggested_search, serpapi_result, bs4_content_type_img

# bs4_suggested_search.get_suggested_search_data()
bs4_original_images.get_images_data()
# bs4_content_type_img.get_images_with_headers()

# serpapi_result.get_google_images()